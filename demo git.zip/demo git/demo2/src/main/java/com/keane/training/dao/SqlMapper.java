package com.keane.training.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import com.keane.dbfw.ResultMapper;
import com.keane.training.domain.Users;
import com.keane.training.domain.PersonalDetails;
import com.keane.training.domain.Admin;

public class SqlMapper {

	// database : mydb
	// table Name : user_info 
	// fields :  portalid(int (6)), name (varchar), employeeid(int 6), technology (varchar), password (varchar)
	
	
	public static final String FETCH_USER = "select name,employeeId,technology,password from user_info where portalid=?";
	public static final String ADD_USER = "insert into user_info values(?,?,?,?,?)"; 
	// pharmacy
	public static final String FETCH_USERS = "select user_id,password,email,age,con_no,city,state,pincode from user_reg where user_id =? and password=?";
	public static final String ADD_USERS = "insert into user_reg values(?,?,?,?,?,?,?,?)"; 
	
	public static final String INSERTADMIN ="insert into admin_reg values(?,?,?,?,?,?,?,?)"; 
	public static final String FETCH_ADMIN = "select admin_id,password,email,age,con_no,city,state,pincode from admin_reg where admin_id =? and password =?";
	public static final String ADD_PersonalDetails = "insert into personal_info values(?,?,?,?,?,?)";
	
	
	
	public static final ResultMapper MAP_USERS = new ResultMapper() {

		@Override
		public Object mapRows(ResultSet rs) throws SQLException {
			Users user = new Users();
			user.setUser_id(rs.getInt("user_id"));
			user.setPassword(rs.getString("password"));
			return user;
		}
			
		};
	
		public static final ResultMapper MAP_ADMIN = new ResultMapper() {

			@Override
			public Object mapRows(ResultSet rs) throws SQLException {
				Admin a = new Admin();
				 a.setAdmin_id(rs.getInt("admin_id"));
				a.setPassword(rs.getString("password"));
				
				return a;
				
			}		
		};
		public static final ResultMapper MAP_PersonalDetails= new ResultMapper() {

			@Override
			public Object mapRows(ResultSet rs) throws SQLException {
				PersonalDetails ab = new PersonalDetails();
				
				ab.setMobileno(rs.getInt("mobileno"));
				ab.setFirstname(rs.getString("firstname"));
				
				return ab;
				
			}
		};
		
}
	
	