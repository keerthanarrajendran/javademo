package com.keane.training.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.keane.dbcon.ConnectionHolder;
import com.keane.dbcon.DBConnectionException;
import com.keane.dbfw.DBFWException;
import com.keane.dbfw.DBHelper;
import com.keane.dbfw.ParamMapper;
import com.keane.training.domain.PersonalDetails;
import com.keane.training.domain.Users;

public class PersonalDetailsDAO {
	
	
	public int insertPersonalDetails(final PersonalDetails personaldetails) throws DAOAppException {
		ConnectionHolder ch = null;
		Connection con = null;
		int res = -1;
		
		ParamMapper mapper = new ParamMapper() 
		{
			@Override
			public void mapParams(PreparedStatement pStmt) throws SQLException
			{
				pStmt.setInt(1, personaldetails.getMobileno());
				pStmt.setString(2, personaldetails.getFirsttname());
				pStmt.setString(3, personaldetails.getLastname());
				pStmt.setString(4, personaldetails.getAddress());
				pStmt.setString(5, personaldetails.getCity());
				pStmt.setString(6, personaldetails.getState());
				
				
			}
		};
		  		try {
			ch = ConnectionHolder.getInstance();
			con = ch.getConnection();
			res = DBHelper.executeUpdate(con, SqlMapper.ADD_PersonalDetails, mapper);

		} catch (DBConnectionException e) {
			throw new DAOAppException(e);
		} catch (DBFWException e) {
			throw new DAOAppException(e);
		}
		return res;
	}

	
	
}
