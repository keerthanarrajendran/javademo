package com.keane.training.web.handlers;



import java.io.IOException;
import java.io.PrintWriter;

import org.apache.log4j.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.keane.mvc.HttpRequestHandler;
import com.keane.training.dao.DAOAppException;
import com.keane.training.dao.AdminDAO;
import com.keane.training.domain.Admin;

public class RegisterAdmin implements HttpRequestHandler {
	
	static Logger log = Logger.getLogger(RegisterAdmin.class);
	
	
	public void handle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter(); 
		
		
		
		AdminDAO dao = new AdminDAO();
		Admin a= new Admin();
		
		
		
		a.setAdmin_id(Integer.parseInt(request.getParameter("admin_id")));
		a.setPassword(request.getParameter("password"));
		a.setEmail(request.getParameter("email"));
		a.setAge(Integer.parseInt(request.getParameter("admin_id")));
		a.setCon_no(request.getParameter("email"));
		a.setCity(request.getParameter("email"));
		a.setState(request.getParameter("email"));
		a.setPincode(Integer.parseInt(request.getParameter("admin_id")));
			int finalResult;
			try {
				finalResult = dao.registerAdmin(a);
				if(finalResult>0) 
				{
					out.println("<html><body><b>Successfully Inserted"
	                        + "</b></body></html>");
					
				}
			} catch (DAOAppException e) {
			
				e.printStackTrace();
			}
	}



	
}
