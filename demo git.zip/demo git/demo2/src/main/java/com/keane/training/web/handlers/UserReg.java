package com.keane.training.web.handlers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.keane.mvc.HttpRequestHandler;
import com.keane.training.dao.AdminDAO;
import com.keane.training.dao.DAOAppException;
import com.keane.training.dao.UserRegDao;
import com.keane.training.domain.Admin;
import com.keane.training.domain.Users;

public class UserReg implements HttpRequestHandler 
{
	
static Logger log = Logger.getLogger(UserReg.class);
	
	
	public void handle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter(); 
		
		
		
		UserRegDao dao = new UserRegDao();
		Users a= new Users();
		
		
		
		a.setUser_id(Integer.parseInt(request.getParameter("user_id")));
		a.setPassword(request.getParameter("password"));
		a.setEmail(request.getParameter("email"));
		a.setAge(Integer.parseInt(request.getParameter("age")));
		a.setCon_no(request.getParameter("con_no"));
		a.setCity(request.getParameter("city"));
		a.setState(request.getParameter("state"));
		a.setPincode(Integer.parseInt(request.getParameter("pincode")));
		
			int finalResult;
			try {
				finalResult = dao.registerUser(a);
				if(finalResult>0) 
				{
					out.println("<html><body><b>Successfully Inserted"
	                        + "</b></body></html>");
					
				}
			} catch (DAOAppException e) {
			
				e.printStackTrace();
			}
	}



	
}
