package com.keane.training.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.keane.dbcon.ConnectionHolder;
import com.keane.dbcon.DBConnectionException;
import com.keane.dbfw.DBFWException;
import com.keane.dbfw.DBHelper;
import com.keane.dbfw.ParamMapper;
import com.keane.training.domain.Admin;
import com.keane.training.domain.Users;

public class UserRegDao {
	public int registerUser(final Users a) throws DAOAppException {
		ConnectionHolder ch = null;
		Connection con = null;
		int res = -1;
		
		ParamMapper mapper = new ParamMapper() 
		{
			@Override
			public void mapParams(PreparedStatement preStmt) throws SQLException 
			{
				preStmt.setInt(1, a.getUser_id());	
				preStmt.setString(2, a.getPassword());
				preStmt.setString(3, a.getEmail());
				preStmt.setInt(4, a.getAge());	
				preStmt.setString(5, a.getCon_no());
				preStmt.setString(6, a.getCity());
				preStmt.setString(7, a.getState());
				preStmt.setInt(8, a.getPincode());	
		
			}

		};
		  		try {
			ch = ConnectionHolder.getInstance();
			con = ch.getConnection();
			res = DBHelper.executeUpdate(con,SqlMapper.ADD_USERS,mapper);
			
		} catch (DBConnectionException e) {
			throw new DAOAppException(e);
		} catch (DBFWException e) {
			throw new DAOAppException(e);
		}
		return res;
	}
	public boolean validateUsers(final int user_id,final String password) throws DAOAppException {
		ConnectionHolder ch = null;
		Connection con = null;
		List admins = null;

		ParamMapper paramMapper = new ParamMapper() {

			@Override
			public void mapParams(PreparedStatement pStmt) throws SQLException {
				pStmt.setInt(1, user_id);
				pStmt.setString(2, password);
			}
		};
		try {
			ch = ConnectionHolder.getInstance();
			con = ch.getConnection();
			admins= DBHelper.executeSelect(con, SqlMapper.FETCH_USERS,paramMapper, SqlMapper.MAP_ADMIN);

		} catch (DBConnectionException e) {
			throw new DAOAppException(e);
		} catch (DBFWException e) {
			throw new DAOAppException(e);
		}

		return (admins != null && admins.size() > 0);

	}
}
