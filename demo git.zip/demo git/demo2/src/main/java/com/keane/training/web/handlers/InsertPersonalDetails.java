package com.keane.training.web.handlers;

import com.keane.mvc.HttpRequestHandler;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import com.keane.training.dao.DAOAppException;
import com.keane.training.dao.UserRegDao;
import com.keane.training.domain.Users;
import com.keane.training.dao.PersonalDetailsDAO;
import com.keane.training.domain.PersonalDetails;

public class InsertPersonalDetails implements HttpRequestHandler {
	
	static Logger log = Logger.getLogger(InsertPersonalDetails.class);
	
	
	public void handle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter(); 
		
		
		PersonalDetailsDAO dao = new PersonalDetailsDAO();
		PersonalDetails a= new PersonalDetails();
		
		
		a.setMobileno(Integer.parseInt(request.getParameter("mobileno")));
		a.setFirstname(request.getParameter("firstname"));
		a.setLastname(request.getParameter("lastname"));
		
		
		
		a.setAddress(request.getParameter("address"));
		a.setCity(request.getParameter("city"));
		a.setState(request.getParameter("state"));
		
		
			int finalResult;
			try {
				finalResult = dao.insertPersonalDetails(a);
				if(finalResult>0) {
					out.println("<html><body><b>Successfully Inserted"
	                        + "</b></body></html>");
					
				}
			} catch (DAOAppException e) {
			
				e.printStackTrace();
			}
	}

	
}